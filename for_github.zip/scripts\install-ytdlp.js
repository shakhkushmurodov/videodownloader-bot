#!/usr/bin/env node
/**
 * yt-dlp binary o'rnatish skripti
 * `npm install` tugagandan keyin avtomatik ishga tushadi (postinstall)
 * Render.com va boshqa Linux serverlarda yt-dlp'ni yuklab oladi
 */
const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const YTDLP_URL = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp';
const LOCAL_BIN = path.join(__dirname, '..', 'yt-dlp');
const SYSTEM_BIN = '/usr/local/bin/yt-dlp';

// Agar allaqachon o'rnatilgan bo'lsa, o'tkazib yuboramiz
if (fs.existsSync(SYSTEM_BIN) || fs.existsSync(LOCAL_BIN)) {
    console.log('[install-ytdlp] yt-dlp allaqachon mavjud, o\'tkazib yuborildi.');
    process.exit(0);
}

// Windows'da o'rnatish shart emas (lokal ishlab chiqish)
if (process.platform === 'win32') {
    console.log('[install-ytdlp] Windows aniqlandi, o\'tkazib yuborildi.');
    process.exit(0);
}

console.log('[install-ytdlp] yt-dlp yuklanmoqda...');

// Avval system PATH'ga o'rnatishga harakat qilamiz
let installPath = LOCAL_BIN;
try {
    execSync(`curl -L "${YTDLP_URL}" -o "${SYSTEM_BIN}" && chmod +x "${SYSTEM_BIN}"`, { stdio: 'inherit' });
    console.log(`[install-ytdlp] yt-dlp o'rnatildi: ${SYSTEM_BIN}`);
    process.exit(0);
} catch {
    // System path'ga yoza olmasak, local path ishlatamiz
    console.log('[install-ytdlp] System path\'ga yozib bo\'lmadi, lokal saqlanmoqda...');
}

// Lokal katalogga yuklaymiz
const file = fs.createWriteStream(LOCAL_BIN);
https.get(YTDLP_URL, (res) => {
    if (res.statusCode === 302 || res.statusCode === 301) {
        // Redirect'ni kuzatamiz
        https.get(res.headers.location, (res2) => {
            res2.pipe(file);
            file.on('finish', () => {
                file.close();
                fs.chmodSync(LOCAL_BIN, '755');
                console.log(`[install-ytdlp] yt-dlp o'rnatildi: ${LOCAL_BIN}`);
            });
        });
    } else {
        res.pipe(file);
        file.on('finish', () => {
            file.close();
            fs.chmodSync(LOCAL_BIN, '755');
            console.log(`[install-ytdlp] yt-dlp o'rnatildi: ${LOCAL_BIN}`);
        });
    }
}).on('error', (err) => {
    console.error('[install-ytdlp] Yuklashda xato:', err.message);
    try { fs.unlinkSync(LOCAL_BIN); } catch { }
});
